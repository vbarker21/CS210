#include <iostream>
#include <fstream>
#include <map>
#include <string>

class ItemTracker {
private:
    std::map<std::string, int> itemsFrequency;

public:
    ItemTracker() {
        
        std::ifstream inputFile("CS210_Project_Three_Input_File.txt");
        if (inputFile.is_open()) {
            std::string item;
            while (std::getline(inputFile, item)) {
                itemsFrequency[item]++;
            }
            inputFile.close();
        }
        else {
            std::cout << "Unable to open input file." << std::endl;
        }
    }

    void searchItem() {
        std::string item;
        std::cout << "Enter the item you wish to look for: ";
        std::getline(std::cin >> std::ws, item); 

        
        if (itemsFrequency.find(item) != itemsFrequency.end()) {
            int frequency = itemsFrequency[item];
            std::cout << "Frequency of " << item << ": " << frequency << std::endl;
        }
        else {
            std::cout << "Item not found." << std::endl;
        }
    }

    void printFrequencyList() {
        
        for (const auto& pair : itemsFrequency) {
            std::cout << pair.first << " " << pair.second << std::endl;
        }
    }

    void printHistogram() {
        
        for (const auto& pair : itemsFrequency) {
            std::cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    ItemTracker itemTracker;

    int choice;
    do {
        std::cout << "Menu Options:" << std::endl;
        std::cout << "1. Search for an item" << std::endl;
        std::cout << "2. Print frequency list" << std::endl;
        std::cout << "3. Print histogram" << std::endl;
        std::cout << "4. Exit" << std::endl;
        std::cout << "Enter your choice (1-4): ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            itemTracker.searchItem();
            break;
        case 2:
            itemTracker.printFrequencyList();
            break;
        case 3:
            itemTracker.printHistogram();
            break;
        case 4:
            std::cout << "Exiting the program." << std::endl;
            break;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }
    } while (choice != 4);

    return 0;
}
